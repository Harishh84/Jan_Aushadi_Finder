package com.example.janayushadifinder20.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.janayushadifinder20.data.Medicine
import com.example.janayushadifinder20.data.MedicineRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

@Composable
fun SearchScreen() {
    var searchQuery by remember { mutableStateOf("") }
    val filteredMedicines = remember(searchQuery) {
        MedicineRepository.searchMedicines(searchQuery)
    }
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Text(
                text = "Medicine Search",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Search branded medicine (e.g. Crocin)") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                shape = MaterialTheme.shapes.medium
            )

            Spacer(modifier = Modifier.height(16.dp))

            if (searchQuery.isEmpty()) {
                Text(
                    "Start typing to find generic alternatives and see potential savings.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.Gray
                )
            } else if (filteredMedicines.isEmpty()) {
                Text(
                    "No medicines found matching \"$searchQuery\"",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.Gray
                )
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(filteredMedicines) { medicine ->
                        MedicineCard(medicine) {
                            scope.launch {
                                snackbarHostState.showSnackbar("Checking availability for ${medicine.genericName} at nearby stores...")
                                delay(1500)
                                snackbarHostState.showSnackbar("Success: In stock at 3 Jan-Aushadhi Kendras nearby!")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MedicineCard(medicine: Medicine, onCheckAvailability: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = medicine.brandName,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = medicine.genericName,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Medium
                    )
                }
                Surface(
                    color = Color(0xFFE8F5E9),
                    shape = MaterialTheme.shapes.small
                ) {
                    Text(
                        text = "SAVE ${String.format(Locale.getDefault(), "%.0f", medicine.savingsPercentage)}%",
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelLarge,
                        color = Color(0xFF2E7D32),
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = "Composition: ${medicine.saltComposition}",
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray
            )
            
            HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), thickness = 0.5.dp)
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Branded Price", style = MaterialTheme.typography.labelMedium, color = Color.Gray)
                    Text("₹${medicine.brandPrice}", style = MaterialTheme.typography.bodyLarge, color = Color.Gray)
                }
                Column(horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
                    Text("Generic Price", style = MaterialTheme.typography.labelMedium, color = Color.Gray)
                    Text("₹${medicine.genericPrice}", style = MaterialTheme.typography.titleMedium, color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold)
                }
                Column(horizontalAlignment = androidx.compose.ui.Alignment.End) {
                    Text("Total Savings", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Text("₹${medicine.savings}", style = MaterialTheme.typography.titleLarge, color = Color(0xFF2E7D32), fontWeight = FontWeight.ExtraBold)
                }
            }
            
            Button(
                onClick = onCheckAvailability,
                modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
                contentPadding = PaddingValues(8.dp)
            ) {
                Text("Check Availability (Simulated)")
            }
        }
    }
}
