package com.example.janayushadifinder20.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Place
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

data class Store(val name: String, val address: String, val distance: String, val isOpen: Boolean, val area: String)

@Composable
fun MapScreen() {
    val stores = listOf(
        Store("Jan Aushadhi Kendra - Sector 15", "Shop 4, HUDA Market", "0.8 km", true, "Indiranagar"),
        Store("PMBJK Store - Govt Hospital", "Main Gate, Civil Wing", "1.5 km", true, "Koramangala"),
        Store("Generic Medicine Hub", "12/A, Station Road", "2.3 km", false, "MG Road"),
        Store("Jan Aushadhi Outlet - Metro", "Kiosk 2, Exit 3", "3.1 km", true, "Jayanagar"),
        Store("Arogya Kendra", "Opposite Post Office", "4.5 km", true, "Whitefield"),
        Store("Pradhan Mantri Bhartiya Janaushadhi", "B-Block, Community Center", "5.2 km", true, "Hebbal")
    )

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text(
            text = "Store Locator",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // Improved Simulated Map View
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(250.dp)
                .background(Color(0xFFE1F5FE), shape = MaterialTheme.shapes.medium)
                .border(1.dp, Color.LightGray, MaterialTheme.shapes.medium),
            contentAlignment = Alignment.Center
        ) {
            // Draw some "roads" and "buildings" for a better simulation
            Column(modifier = Modifier.fillMaxSize()) {
                Box(modifier = Modifier.fillMaxWidth().height(40.dp).background(Color(0xFFB0BEC5))) // Road
                Spacer(modifier = Modifier.weight(1f))
                Box(modifier = Modifier.fillMaxWidth().height(40.dp).background(Color(0xFFB0BEC5))) // Road
            }
            
            // "You are here" marker
            Surface(
                shape = CircleShape,
                color = Color(0x332196F3),
                modifier = Modifier.size(100.dp)
            ) {}
            Icon(
                Icons.Default.Place,
                contentDescription = null, 
                modifier = Modifier.size(24.dp), 
                tint = Color(0xFF1976D2)
            )

            // Store markers
            Icon(Icons.Default.LocationOn, null, Modifier.offset(x = (-60).dp, y = (-40).dp).size(32.dp), Color.Red)
            Icon(Icons.Default.LocationOn, null, Modifier.offset(x = 80.dp, y = 30.dp).size(32.dp), Color.Red)
            Icon(Icons.Default.LocationOn, null, Modifier.offset(x = (-30).dp, y = 70.dp).size(32.dp), Color.Red)

            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(8.dp)
                    .background(Color.White.copy(alpha = 0.8f), shape = MaterialTheme.shapes.small)
                    .padding(4.dp)
            ) {
                Text("Simulated Map View", style = MaterialTheme.typography.labelSmall)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text("Nearby Jan-Aushadhi Kendras", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
            items(stores) { store ->
                StoreCard(store)
            }
        }
    }
}

@Composable
fun StoreCard(store: Store) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Default.LocationOn, 
                contentDescription = null, 
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(store.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                Text("${store.area} | ${store.address}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(store.distance, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                    Spacer(modifier = Modifier.width(8.dp))
                    if (store.isOpen) {
                        Surface(color = Color(0xFFE8F5E9), shape = MaterialTheme.shapes.extraSmall) {
                            Text("OPEN NOW", modifier = Modifier.padding(horizontal = 4.dp), color = Color(0xFF2E7D32), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Surface(color = Color(0xFFFFEBEE), shape = MaterialTheme.shapes.extraSmall) {
                            Text("CLOSED", modifier = Modifier.padding(horizontal = 4.dp), color = Color.Red, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            Button(onClick = { /* Navigate */ }, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp)) {
                Text("Go", style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}
