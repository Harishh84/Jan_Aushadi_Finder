package com.example.janayushadifinder20.data

import java.util.Locale

object MedicineRepository {
    val medicines = listOf(
        Medicine(1, "Crocin", "Paracetamol", 30.0, 5.0, "Paracetamol 500mg"),
        Medicine(2, "Augmentin", "Amoxycillin + Clavulanic Acid", 200.0, 60.0, "Amoxycillin 500mg + Clavulanic Acid 125mg"),
        Medicine(3, "Combiflam", "Ibuprofen + Paracetamol", 45.0, 10.0, "Ibuprofen 400mg + Paracetamol 325mg"),
        Medicine(4, "Lipitor", "Atorvastatin", 150.0, 25.0, "Atorvastatin 10mg"),
        Medicine(5, "Zantac", "Ranitidine", 40.0, 8.0, "Ranitidine 150mg"),
        Medicine(6, "Amoxil", "Amoxicillin", 60.0, 15.0, "Amoxicillin 500mg"),
        Medicine(7, "Glucophage", "Metformin", 80.0, 12.0, "Metformin 500mg"),
        Medicine(8, "Voveran", "Diclofenac", 55.0, 12.0, "Diclofenac 50mg"),
        Medicine(9, "Pan D", "Pantoprazole + Domperidone", 120.0, 30.0, "Pantoprazole 40mg + Domperidone 30mg"),
        Medicine(10, "Taxim O", "Cefixime", 180.0, 45.0, "Cefixime 200mg"),
        Medicine(11, "Dolo 650", "Paracetamol", 30.0, 4.0, "Paracetamol 650mg"),
        Medicine(12, "Calpol", "Paracetamol", 28.0, 4.5, "Paracetamol 500mg"),
        Medicine(13, "Allegra", "Fexofenadine", 180.0, 40.0, "Fexofenadine 120mg"),
        Medicine(14, "Avil", "Pheniramine Maleate", 20.0, 3.0, "Pheniramine Maleate 25mg"),
        Medicine(15, "Limcee", "Vitamin C", 50.0, 10.0, "Vitamin C 500mg"),
        Medicine(16, "Shelcal", "Calcium + Vitamin D3", 120.0, 35.0, "Calcium 500mg + Vitamin D3 250IU"),
        Medicine(17, "Omez", "Omeprazole", 60.0, 12.0, "Omeprazole 20mg"),
        Medicine(18, "Liv.52", "Herbal Liver Support", 150.0, 80.0, "Herbal Extracts"),
        Medicine(19, "Digene", "Antacid", 45.0, 15.0, "Magnesium Hydroxide + Aluminium Hydroxide"),
        Medicine(20, "Saridon", "Propyphenazone + Paracetamol + Caffeine", 40.0, 12.0, "Propyphenazone + Paracetamol + Caffeine"),
        Medicine(21, "Telma 40", "Telmisartan", 110.0, 22.0, "Telmisartan 40mg"),
        Medicine(22, "Amlokind 5", "Amlodipine", 45.0, 8.0, "Amlodipine 5mg"),
        Medicine(23, "Thyronorm", "Thyroxine", 160.0, 45.0, "Thyroxine 50mcg"),
        Medicine(24, "Pan 40", "Pantoprazole", 115.0, 25.0, "Pantoprazole 40mg"),
        Medicine(25, "Aciloc 150", "Ranitidine", 30.0, 6.0, "Ranitidine 150mg"),
        Medicine(26, "Okacet", "Cetirizine", 35.0, 8.0, "Cetirizine 10mg"),
        Medicine(27, "Montair LC", "Montelukast + Levocetirizine", 180.0, 45.0, "Montelukast 10mg + Levocetirizine 5mg"),
        Medicine(28, "Azithral 500", "Azithromycin", 130.0, 35.0, "Azithromycin 500mg"),
        Medicine(29, "Ciplox 500", "Ciprofloxacin", 70.0, 15.0, "Ciprofloxacin 500mg"),
        Medicine(30, "Meftal Spas", "Mefenamic Acid + Dicyclomine", 65.0, 18.0, "Mefenamic Acid 250mg + Dicyclomine 10mg"),
        Medicine(31, "Glycomet 500", "Metformin", 45.0, 10.0, "Metformin 500mg"),
        Medicine(32, "Janumet 50/500", "Sitagliptin + Metformin", 320.0, 85.0, "Sitagliptin 50mg + Metformin 500mg"),
        Medicine(33, "Galvus Met", "Vildagliptin + Metformin", 280.0, 75.0, "Vildagliptin 50mg + Metformin 500mg"),
        Medicine(34, "Forxiga 10", "Dapagliflozin", 450.0, 120.0, "Dapagliflozin 10mg"),
        Medicine(35, "Jardiance 10", "Empagliflozin", 520.0, 140.0, "Empagliflozin 10mg"),
        Medicine(36, "Telma H", "Telmisartan + Hydrochlorothiazide", 140.0, 35.0, "Telmisartan 40mg + HCTZ 12.5mg"),
        Medicine(37, "Revelol AM", "Metoprolol + Amlodipine", 160.0, 45.0, "Metoprolol 25mg + Amlodipine 5mg"),
        Medicine(38, "Cilacar T", "Cilnidipine + Telmisartan", 180.0, 50.0, "Cilnidipine 10mg + Telmisartan 40mg"),
        Medicine(39, "Concor 5", "Bisoprolol", 120.0, 30.0, "Bisoprolol 5mg"),
        Medicine(40, "Arkamin", "Clonidine", 50.0, 12.0, "Clonidine 100mcg"),
        Medicine(41, "Lasix", "Furosemide", 15.0, 4.0, "Furosemide 40mg"),
        Medicine(42, "Dytor 10", "Torsemide", 80.0, 20.0, "Torsemide 10mg"),
        Medicine(43, "Pantocid 40", "Pantoprazole", 130.0, 28.0, "Pantoprazole 40mg"),
        Medicine(44, "Sompraz 40", "Esomeprazole", 150.0, 35.0, "Esomeprazole 40mg"),
        Medicine(45, "Rabium 20", "Rabeprazole", 110.0, 25.0, "Rabeprazole 20mg"),
        Medicine(46, "Ganaton", "Itopride", 220.0, 60.0, "Itopride 50mg"),
        Medicine(47, "Rantac 150", "Ranitidine", 35.0, 7.0, "Ranitidine 150mg"),
        Medicine(48, "Sporlac", "Lactic Acid Bacillus", 90.0, 30.0, "Bacillus Coagulans"),
        Medicine(49, "Zincovit", "Multivitamins + Minerals", 105.0, 35.0, "Vitamins + Zinc + Selenium"),
        Medicine(50, "Dexorange", "Iron + Vitamin B12 + Folic Acid", 160.0, 65.0, "Ferric Ammonium Citrate"),
        Medicine(51, "Supradyn", "Multivitamins", 55.0, 15.0, "Vitamins + Minerals + Trace Elements"),
        Medicine(52, "Evion 400", "Vitamin E", 95.0, 25.0, "Vitamin E 400mg"),
        Medicine(53, "Atorva 10", "Atorvastatin", 110.0, 22.0, "Atorvastatin 10mg"),
        Medicine(54, "Rosuvas 10", "Rosuvastatin", 180.0, 40.0, "Rosuvastatin 10mg"),
        Medicine(55, "Clopilet 75", "Clopidogrel", 120.0, 30.0, "Clopidogrel 75mg"),
        Medicine(56, "Ecosprin 75", "Aspirin", 10.0, 3.0, "Aspirin 75mg"),
        Medicine(57, "Wikoryl", "Phenylephrine + CPM + Paracetamol", 55.0, 15.0, "Phenylephrine 5mg + CPM 2mg + Paracetamol 500mg"),
        Medicine(58, "Ascoril LS", "Ambroxol + Levosalbutamol", 115.0, 45.0, "Ambroxol 30mg + Levosalbutamol 1mg"),
        Medicine(59, "Grilinctus", "Cough Formula", 130.0, 55.0, "Dextromethorphan + CPM"),
        Medicine(60, "Duolin", "Levosalbutamol + Ipratropium", 90.0, 35.0, "Levosalbutamol 1.25mg + Ipratropium 500mcg"),
        Medicine(61, "Amlong 5", "Amlodipine", 40.0, 8.0, "Amlodipine 5mg"),
        Medicine(62, "Losar 50", "Losartan", 90.0, 18.0, "Losartan 50mg"),
        Medicine(63, "Stemetil 5", "Prochlorperazine", 115.0, 35.0, "Prochlorperazine 5mg"),
        Medicine(64, "Vertin 16", "Betahistine", 140.0, 40.0, "Betahistine 16mg"),
        Medicine(65, "Temptal Spas", "Mefenamic Acid + Dicyclomine", 60.0, 15.0, "Mefenamic Acid 250mg + Dicyclomine 10mg"),
        Medicine(66, "Cetzine", "Cetirizine", 45.0, 10.0, "Cetirizine 10mg"),
        Medicine(67, "Eldoper", "Loperamide", 35.0, 8.0, "Loperamide 2mg"),
        Medicine(68, "Folvite", "Folic Acid", 75.0, 12.0, "Folic Acid 5mg"),
        Medicine(69, "Cyclopam", "Dicyclomine + Paracetamol", 55.0, 15.0, "Dicyclomine 10mg + Paracetamol 500mg"),
        Medicine(70, "Pruvict 2", "Prucalopride", 250.0, 80.0, "Prucalopride 2mg")
    )

    fun searchMedicines(query: String): List<Medicine> {
        if (query.isEmpty()) return emptyList()
        val lowerQuery = query.lowercase(Locale.getDefault())
        
        // 1. Exact or contains matches
        val matches = medicines.filter {
            it.brandName.lowercase().contains(lowerQuery) || 
            it.genericName.lowercase().contains(lowerQuery)
        }
        
        if (matches.isNotEmpty()) return matches

        // 2. Fuzzy Search: Handle small spelling mistakes
        return medicines.filter {
            levenshteinDistance(it.brandName.lowercase(), lowerQuery) <= 2 ||
            levenshteinDistance(it.genericName.lowercase(), lowerQuery) <= 2
        }.sortedBy { 
            levenshteinDistance(it.brandName.lowercase(), lowerQuery) 
        }
    }

    private fun levenshteinDistance(s1: String, s2: String): Int {
        val dp = Array(s1.length + 1) { IntArray(s2.length + 1) }
        for (i in 0..s1.length) dp[i][0] = i
        for (j in 0..s2.length) dp[0][j] = j

        for (i in 1..s1.length) {
            for (j in 1..s2.length) {
                val cost = if (s1[i - 1] == s2[j - 1]) 0 else 1
                dp[i][j] = minOf(
                    dp[i - 1][j] + 1,
                    dp[i][j - 1] + 1,
                    dp[i - 1][j - 1] + cost
                )
            }
        }
        return dp[s1.length][s2.length]
    }
}
