package com.example.janayushadifinder20.data

data class Medicine(
    val id: Int,
    val brandName: String,
    val genericName: String,
    val brandPrice: Double,
    val genericPrice: Double,
    val saltComposition: String
) {
    val savings: Double
        get() = brandPrice - genericPrice

    val savingsPercentage: Double
        get() = (savings / brandPrice) * 100
}
